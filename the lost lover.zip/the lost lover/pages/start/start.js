// start.js
Page({
  data: {
    imm: "http://img.pconline.com.cn/images/upload/upc/tx/itbbs/1507/06/c14/9355933_1436148088585.jpg"  ,
    inn:"http://seopic.699pic.com/photo/50058/6267.jpg_wh1200.jpg",
    immm:true,
    modalHidden: true,
    opacity: 0.4,
    disabled: true,
    threshold: 0,
    rule: 'up',
    countDownSecond: '蓄力中，请等待3s',//防止因为时间过快导致的硬件端未接收到数据
    mmd:true,
    ccc:'有人'
  },
     modalBindaconfirm:function(){ 
       var that = this;
       this.setData({
         countDownSecond: '蓄力中，请等待3s',
       })
       wx.request({//运用数据流来发送开关这个数据，这里在弹出来的两个选项中都标准同样的代码
         url: 'https://api.heclouds.com/devices/576044344/datapoints?type=3',
         method: 'post',
         data: {
           kaiguan: '0'  //这里是发送给服务器的参数（参数名：参数值）  
         },
         header: {
           'content-type': 'application/json',
           'api-key': '4JN3dVA6baqtrn0t59IEPVdXA7w='
         },
         success: function (res) {
           that.setData({ //这里是修改data的值  
             test: res.data //test等于服务器返回来的数据  
           });
           console.log(res.data)
         },
         fail: (err) => {
           reject(err)
         }
       })
          this.setData({    
         modalHidden:!this.data.modalHidden })  },  
          modalBindcancel:function(){  
            this.setData({
              countDownSecond: '蓄力中，请等待3s',
            })  
            var that = this
            wx.request({
              url: 'https://api.heclouds.com/devices/576044344/datapoints?type=3',
              method: 'post',
              data: {
                kaiguan: '0'  //这里是发送给服务器的参数（参数名：参数值）  
              },
              header: {
                'content-type': 'application/json',
                'api-key': '4JN3dVA6baqtrn0t59IEPVdXA7w='
              },
              success: function (res) {
                that.setData({ //这里是修改data的值  
                  test: res.data //test等于服务器返回来的数据  
                });
                console.log(res.data)
              },
              fail: (err) => {
                reject(err)
              }
            })
            this.setData({   
               modalHidden:!this.data.modalHidden,   
                })  
               },
  openwindow: function () {
    var is = "immm";
    if (this.data.immm == 0) {
      this.setData({
        [is]: 1
      })
    } else if (this.data.immm == 1) {
      this.setData({
        [is]: 0
      })
    }
    this.setData({ modalHidden: !this.data.modalHidden })
    var that = this //创建一个名为that的变量来保存this当前的值  
    wx.request({
      url: 'https://api.heclouds.com/devices/576044344/datapoints?type=3',
      method: 'post',
      data: {
        kaiguan: '1'  //这里是发送给服务器的参数（参数名：参数值）  
      },
      header: {
        'content-type': 'application/json',
        'api-key': '4JN3dVA6baqtrn0t59IEPVdXA7w='
      },
      success: function (res) {
        that.setData({ //这里是修改data的值  
          test: res.data //test等于服务器返回来的数据  
        });
        console.log(res.data)
      },
      fail: (err) => {
        reject(err)
      }
    })
    var ll = Date.parse(new Date())/1000;
    var interval = setInterval(function () {
      var sec =3+ll-Date.parse(new Date())/1000;
      var secStr = sec.toString();
      if (secStr>=0)
      this.setData({
        countDownSecond: '蓄力中，请等待'+secStr+'s',
      })
      if (this.data.countDownSecond == '蓄力中，请等待0s'){
        this.setData({
          countDownSecond: '我已经为主人打开了门',
        })
      }
    }.bind(this), 1000);
    },
    navigate: function() {//跳转到获取天气的代码区
        wx.navigateTo({
            url: '../wifi_station/tianqi/tianqi',
        })
    }
})
